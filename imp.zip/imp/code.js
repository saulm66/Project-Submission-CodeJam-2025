var score = 0;
var circuit = 0;
var timescore = 0;

onEvent("input", "click", function( ) {
  if (getText("bruh") == "") {
    console.log("input please");
  } else {
    kevinn(getText("bruh"));
  }
  timescore += 1;
});

onEvent("endbutton", "click", function( ) {
  if (timescore > 0){
    circuit = circuit + 1;
    score = score + 1;
  }
  text();
  timescore = 0;
});

onEvent("charbutton", "click", function( ) {
  setScreen("characterscreen");
});

onEvent("shop", "click", function( ) {
  setProperty("witch", "hidden", false);
  setProperty("cowboy", "hidden", false);
  setProperty("sweater", "hidden", false);
  setProperty("shorts", "hidden", false);
  setProperty("overalls", "hidden", false);
});

onEvent("witch", "click", function(){
  if (score >= 5) {
    setProperty("witchhat", "hidden", false);
    score = score - 5;
  }
});

onEvent("cowboy", "click", function(){
  if (score >= 5) {
    setProperty("cowboyh", "hidden", false);
    score = score - 5;
  }
});

onEvent("sweater", "click", function(){
  if (score >= 10) {
    setProperty("sweat", "hidden", false);
    score = score - 10;
  }
});

onEvent("shorts", "click", function(){
  if (score >= 10) {
    setProperty("short", "hidden", false);
    score = score - 10;
  }
});

onEvent("overalls", "click", function(){
  if (score >= 12) {
    if (getProperty("sweat", "hidden") == false){
      setProperty("overallswfix", "hidden", false);
    } else {
      setProperty("overallsnofix", "hidden", false);
    }
    score = score - 12;
  }
});


onEvent("return", "click", function( ) {
  setScreen("screen1");
  text();
});



function kevinn(input){ 
  var time = input * 1000;
  var timertxt = 0;
  setProperty("time_label", "text", "timer in progress");
  timedLoop(1000, function(){
    timertxt = timertxt + 1;
    console.log(timertxt + " seconds has passed");
    setText("timer", timertxt);
  });
  
  setTimeout(function() {
    console.log("init");
    setProperty("time_label", "hidden", false);
    setProperty("time_label", "text", "timer done");
    setText("timer", input);
    stopTimedLoop();
  }, time + 1);
  
}

function text(){
  setText("scorelbl", "score: " + score);
  setText("circuit", "circuit: " + circuit);
}


